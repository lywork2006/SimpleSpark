#!/bin/bash

docker stop spark210
docker rm spark210
docker build -t spark210 .

sh run.sh
